
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was AirbotSdkConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################


include("${CMAKE_CURRENT_LIST_DIR}/AirbotSdkTargets.cmake")

# 设置头文件目录（用于外部项目引用）
set(AirbotSdk_INCLUDE_DIRS "${CMAKE_CURRENT_LIST_DIR}/../../../include")

# 设置库名（供 find_package 使用）
set(AirbotSdk_LIBRARIES AirbotSdk)
set(AirbotSdk_LIBS AirbotSdk)


# 如果希望项目 find_dependency 自动导入 grpc、protobuf、spdlog 等，可以启用如下：
include(CMakeFindDependencyMacro)


find_dependency(spdlog REQUIRED)


# 标记库已找到
set(AirbotSdk_FOUND TRUE)
