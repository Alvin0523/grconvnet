#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AirbotSdk::AirbotSdk" for configuration "Release"
set_property(TARGET AirbotSdk::AirbotSdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(AirbotSdk::AirbotSdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libAirbotSdk.so"
  IMPORTED_SONAME_RELEASE "libAirbotSdk.so"
  )

list(APPEND _cmake_import_check_targets AirbotSdk::AirbotSdk )
list(APPEND _cmake_import_check_files_for_AirbotSdk::AirbotSdk "${_IMPORT_PREFIX}/lib/libAirbotSdk.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
