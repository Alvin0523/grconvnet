#ifndef ROBOT_MODE_HPP_
#define ROBOT_MODE_HPP_

#include <cstdint>

/**
 * @file robot_mode.hpp
 * @brief Defines control modes for robot arm operations.
 *
 * This file defines various control modes used by the robot arm.
 * Each mode represents a distinct behavior or command interface for controlling the robot.
 *
 * Modes are grouped into:
 * - Planning modes
 * - Servo control modes (in joint/cartesian space)
 * - Special modes like gravity compensation or inactive state
 */

/// @namespace airbot
/// @brief Namespace containing all Airbot SDK related definitions.
namespace airbot {

/**
 * @enum RobotMode
 * @brief Enum class representing the control modes of the robot arm.
 *
 * This enum defines the various modes that the robotic arm can operate in.
 * Each mode controls a distinct behavior or command interface for operating the robot arm.
 */
enum class RobotMode : int {
  /**
   * @brief Planning mode: Single target planning.
   *
   * A single target is sent to the driver, then a motion plan is generated and executed.
   * The target can be a joint position or a cartesian pose.
   */
  PLANNING_POS = 10,

  /**
   * @brief Planning mode: Path planning with multiple waypoints in cartesian space.
   *
   * Performs linear interpolation between all waypoints, then executes the full path.
   */
  PLANNING_WAYPOINTS_PATH = 11,

  /**
   * @brief Planning mode: Local planning between adjacent waypoints.
   *
   * Generates partial plans for each segment, possibly decelerating at waypoints.
   */
  PLANNING_WAYPOINTS = 12,

  /**
   * @brief Servo mode: Joint position control.
   *
   * Continuously receives and executes joint position commands.
   */
  SERVO_JOINT_POS = 20,

  /**
   * @brief Servo mode: Cartesian pose control.
   *
   * Continuously receives and executes cartesian pose commands (position + orientation).
   */
  SERVO_CART_POSE = 21,

  /**
   * @brief Servo mode: Joint velocity control.
   *
   * Continuously receives and executes joint velocity commands.
   */
  SERVO_JOINT_VEL = 24,

  /**
   * @brief Servo mode: Cartesian twist control.
   *
   * Continuously receives cartesian velocity (twist) commands representing the desired
   * linear and angular velocities of the end effector.
   */
  SERVO_CART_TWIST = 25,

  /**
   * @brief MIT integrated mode. In this mode, the robot would
   *        be in a integrated motor joint control, rate is set 250hz.
   */
  MIT_INTEGRATED = 80,

  /**
   * @brief Gravity compensation mode.
   *
   * Robot is in a free-drive state with gravity compensation enabled.
   * No commands are followed, and the robot can be moved manually by external forces.
   */
  GRAVITY_COMP = 90,

  /**
   * @brief Inactive mode.
   *
   * Robot is not performing any tasks or responding to control commands.
   */
  INACTIVE = 98,

  /**
   * @brief Undefined mode.
   *
   * Default or error state; robot mode is not specified.
   */
  UNDEFINED = 99,
};

}  // namespace airbot

#endif  // ROBOT_MODE_HPP_
