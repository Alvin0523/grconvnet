#ifndef AIRBOT_SDK_HPP_
#define AIRBOT_SDK_HPP_

/**
 * @file airbot_sdk.hpp
 * @brief Main SDK interface for controlling Airbot robotic arm.
 *
 * This file contains the declaration of the AirbotSdk class which provides an interface to control
 * and monitor the state of the Airbot robotic arm. It includes methods for managing connection,
 * monitoring state, controlling motion, and loading/unloading applications. All operations are
 * thread-safe.
 *
 * @namespace airbot
 */

#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/spdlog.h>

#include <array>
#include <future>
#include <memory>
#include <string>
#include <variant>
#include <vector>

#include "driver_state.hpp"
#include "robot_mode.hpp"
#include "speed_profile.hpp"

namespace airbot {

// Forward declaration of AirbotArm class
class AirbotArm;

/**
 * @class AirbotSdk
 * @brief Core class for interacting with the Airbot robotic arm.
 *
 * This class provides all necessary methods for interacting with the Airbot robotic arm, such as
 * connecting to the arm, retrieving status information, and controlling motion. It supports both
 * synchronous and asynchronous operations for controlling the robotic arm's joints, end effector,
 * and cartesian pose.
 *
 * Example usage:
 * @code{.cpp}
 * auto sdk  = std::make_unique<AirbotSdk>("192.168.0.xxx", 50051);
 * if (sdk->IsRunning()) {
 *   sdk->GetLogger()->info("SDK start running:");
 *   sdk->GetLogger()->info("Product Info:");
 *   auto info = sdk->GetProductInfo();
 *   for (const auto& [key, value] : info) {
 *     sdk->GetLogger()->info("  {}: {}", key, value);
 *   }
 * }
 * @endcode
 */
class AirbotSdk {
 public:
  /**
   * @brief Constructor that initializes the SDK with the given connection details.
   * @param url The IP address or hostname of the robot (default: "localhost").
   * @param port The port number to connect to (default: 50051).
   *
   * Initializes the SDK instance with the specified connection details. The SDK will not
   * automatically connect to the robot upon initialization. Use `Connect()` to establish a connection.
   */
  AirbotSdk(const std::string& url = "localhost", const unsigned int port = 50051);

  /**
   * @brief Retrieves the logger used by the SDK.
   * @return A shared pointer to the logger instance.
   *
   * The logger can be used to log messages and events from the SDK.
   */
  const std::shared_ptr<spdlog::logger> GetLogger() const;

  /**
   * @brief Checks if the SDK is running and connected to the robotic arm.
   * @return True if the SDK is running, false otherwise.
   *
   * This method checks whether the SDK is currently connected to the robotic arm and is in a running state.
   */
  bool IsRunning() const;

  /**
   * @brief Establishes a connection to the robotic arm.
   * @return True if the connection is successful, false otherwise.
   *
   * Establishes a connection to the robotic arm using the connection details provided during SDK initialization.
   */
  bool Connect() const;

  /**
   * @brief Disconnects from the robotic arm.
   * @return True if the disconnection is successful, false otherwise.
   *
   * Disconnects the SDK from the robotic arm and releases any associated resources.
   */
  bool Disconnect();

  /**
   * @brief Retrieves product information (e.g., name, version) from the robotic arm.
   * @return A vector of key-value pairs containing product information.
   *
   * Retrieves information about the robotic arm, such as its name, version, and other relevant details.
   */
  std::vector<std::pair<std::string, std::vector<std::string>>> GetProductInfo() const;

  /**
   * @brief Retrieves the current state of the robotic arm.
   * @return The current state of the robotic arm.
   *
   * Retrieves the current state of the robotic arm, such as whether it is idle, running, or in an error state.
   */
  State GetState() const;

  /**
   * @brief Retrieves the current control mode of the robotic arm.
   * @return The current robot control mode.
   *
   * Retrieves the current control mode of the robotic arm, such as planning or servo mode.
   */
  RobotMode GetControlMode() const;

  //   /**
  //    * @brief Retrieves the modes available for each robot component.
  //    * @return A pair containing two vectors: one with component names and one with their corresponding modes.
  //    *
  //    * Retrieves the available control modes for each component of the robotic arm.
  //    */
  //   std::pair<std::vector<std::string>, std::vector<RobotMode>> GetMode() const;

  /**
   * @brief Retrieves the parameters of the robotic arm specified by the provided names.
   * @param names A vector of parameter names to retrieve.
   * @return A vector of pairs containing parameter names and their corresponding values.
   *
   * Retrieves the values of the specified parameters from the robotic arm.
   */
  std::vector<std::pair<std::string, std::variant<int32_t, double, std::string, bool>>> GetParams(
      std::vector<std::string> names) const;

  /**
   * @brief Retrieves the end-effector pose (position and orientation) of the robotic arm.
   * @return A pair containing the position (3D vector) and orientation (4D quaternion) of the end-effector.
   *
   * Retrieves the current pose of the end-effector, including its position and orientation.
   */
  std::pair<std::array<double, 3>, std::array<double, 4>> GetEndPose() const;

  /**
   * @brief Retrieves the current joint positions of the robotic arm.
   * @return An array containing the joint positions of the robotic arm.
   *
   * Retrieves the current positions of all joints in the robotic arm.
   */
  std::array<double, 6> GetJointPos() const;

  /**
   * @brief Retrieves the current joint velocities of the robotic arm.
   * @return An array containing the joint velocities of the robotic arm.
   *
   * Retrieves the current velocities of all joints in the robotic arm.
   */
  std::array<double, 6> GetJointVel() const;

  /**
   * @brief Retrieves the current joint efforts (torques) of the robotic arm.
   * @return An array containing the joint efforts (torques) of the robotic arm.
   *
   * Retrieves the current efforts (torques) of all joints in the robotic arm.
   */
  std::array<double, 6> GetJointEff() const;

  /**
   * @brief Retrieves the current position of the end-effector (EEF).
   * @return A vector containing the position of the end-effector.
   *
   * Retrieves the current position of the end-effector.
   */
  std::vector<double> GetEefPos() const;

  /**
   * @brief Retrieves the current velocity of the end-effector (EEF).
   * @return A vector containing the velocity of the end-effector.
   *
   * Retrieves the current velocity of the end-effector.
   */
  std::vector<double> GetEefVel() const;

  /**
   * @brief Retrieves the current force/effort of the end-effector (EEF).
   * @return A vector containing the force/effort of the end-effector.
   *
   * Retrieves the current force or effort applied by the end-effector.
   */
  std::vector<double> GetEefEff() const;

  /**
   * @brief Sets the parameters of the robotic arm.
   * @param params A vector of pairs containing parameter names and their new values.
   * @return True if the parameters are successfully set, false otherwise.
   *
   * Sets the values of the specified parameters on the robotic arm. The parameters must be provided
   * as a vector of pairs, where each pair contains the parameter name and its new value. The function
   * will return true if all parameters are successfully set, otherwise false.
   */
  bool SetParams(
      const std::vector<std::pair<std::string, std::variant<int32_t, double, std::string, bool>>>& params) const;

  /**
   * @brief Sets the speed profile for the robotic arm.
   * @param profile The speed profile to set.
   * @return True if the speed profile is successfully set, false otherwise.
   *
   * Sets the speed profile of the robotic arm, which controls its movement speed and acceleration.
   * Three speed profiles are available:
   * - `SpeedProfile.DEFAULT`: Default speed profile.
   * - `SpeedProfile.SLOW`: Slow speed profile.
   * - `SpeedProfile.FAST`: Fast speed profile. <span style="color: red">**Warning**: \
   *   This speed profile is experimental and may cause the robot to move too fast. \
   *   It is dangerous not to make sure the robot is in a safe environment. \
   *   Use at your own risk.</span>
   */
  bool SetSpeedProfile(const SpeedProfile& profile) const;

  /**
   * @brief Switches the control mode of the robotic arm.
   * @param mode The control mode to switch to.
   * @return True if the mode is successfully switched, false otherwise.
   *
   * Switches the control mode of the robotic arm to the specified mode. The mode must be one of the
   * following:
   * - `RobotMode.PLANNING_POS`: Planning mode. A single target is sent to the driver server, \
   *   then a path is planned and executed.
   * - `RobotMode.SERVO_CART_TWIST`: Servo mode in cartesian space. The robot follows the cartesian \
   *   twist commands.
   * - `RobotMode.SERVO_CART_POSE`: Servo mode in cartesian space. The robot follows the cartesian \
   *   pose commands.
   * - `RobotMode.SERVO_JOINT_POS`: Servo mode in joint space. The robot follows the joint position \
   *   commands.
   * - `RobotMode.SERVO_JOINT_VEL`: Servo mode in joint space. The robot follows the joint velocity \
   *   commands.
   * - `RobotMode.GRAVITY_COMP`: Gravity compensation mode. The robot is in a free-drive state with \
   *   gravity compensated.
   */
  bool SwitchMode(const RobotMode& mode) const;

  /**
   * @brief Switches the control mode for multiple robot components.
   * @param component_names A vector of component names to switch mode for.
   * @param modes A vector of control modes corresponding to each component.
   * @return True if the modes are successfully switched, false otherwise.
   *
   * Switches the control mode for multiple components of the robotic arm. Each component's mode is
   * specified by the corresponding entry in the `modes` vector. The function returns true if all
   * modes are successfully switched, otherwise false.
   */
  bool SwitchMode(const std::vector<std::string>& component_names, const std::vector<RobotMode>& modes) const;

  /**
   * @brief Loads an application onto the robotic arm.
   * @param name The name of the application to load (default: "record_replay_app/record_replay_app::RecordReplayApp").
   * @param params The parameters to pass to the application.
   * @return True if the application is successfully loaded, false otherwise.
   *
   * Loads an application onto the robotic arm. The application name must be specified, and any
   * required parameters can be passed as a vector of pairs. The function returns true if the
   * application is successfully loaded, otherwise false.
   */
  bool LoadApp(const std::string& name = "record_replay_app/record_replay_app::RecordReplayApp",
               const std::vector<std::pair<std::string, std::string>>& params = {}) const;

  /**
   * @brief Unloads the currently loaded application from the robotic arm.
   * @return True if the application is successfully unloaded, false otherwise.
   *
   * Unloads the currently loaded application from the robotic arm. The function returns true if
   * the application is successfully unloaded, otherwise false.
   */
  bool UnloadApp() const;

  /**
   * @brief Moves the robotic arm to the specified joint positions.
   * @param joint_pos An array containing the joint positions to move to.
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm to the specified joint positions. The joint positions must be provided
   * as an array of doubles. The function returns true if the move operation is successful,
   * otherwise false.
   */
  bool MoveToJointPos(const std::array<double, 6>& joint_pos) const;

  /**
   * @brief Asynchronously moves the robotic arm to the specified joint positions.
   * @param joint_pos An array containing the joint positions to move to.
   * @return A future representing the result of the move operation.
   *
   * Asynchronously moves the robotic arm to the specified joint positions. The joint positions
   * must be provided as an array of doubles. The function returns a future that will contain
   * the result of the move operation.
   */
  std::future<bool> AsyncMoveToJointPos(const std::array<double, 6>& joint_pos) const;

  /**
   * @brief Moves the robotic arm to the specified Cartesian position and orientation.
   * @param cart_pos A pair containing the position (3D vector) and orientation (4D quaternion).
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm to the specified Cartesian position and orientation. The position and
   * orientation must be provided as a pair of arrays. The function returns true if the move
   * operation is successful, otherwise false.
   */
  bool MoveToCartPos(const std::pair<std::array<double, 3>, std::array<double, 4>>& cart_pos) const;

  /**
   * @brief Asynchronously moves the robotic arm to the specified Cartesian position and orientation.
   * @param cart_pos A pair containing the position (3D vector) and orientation (4D quaternion).
   * @return A future representing the result of the move operation.
   *
   * Asynchronously moves the robotic arm to the specified Cartesian position and orientation.
   * The position and orientation must be provided as a pair of arrays. The function returns a
   * future that will contain the result of the move operation.
   */
  std::future<bool> AsyncMoveToCartPos(const std::pair<std::array<double, 3>, std::array<double, 4>>& cart_pos) const;

  /**
   * @brief Moves the robotic arm's end-effector to the specified position.
   * @param eef_pos A vector containing the target end-effector position.
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm's end-effector to the specified position. The target position must be
   * provided as a vector of doubles. The function returns true if the move operation is
   * successful, otherwise false.
   */
  /**
   * @brief Moves the robotic arm's end-effector to the specified position.
   * @param eef_pos A vector containing the target end-effector position.
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm's end-effector to the specified position. The target position must be
   * provided as a vector of doubles. The function returns true if the move operation is
   * successful, otherwise false.
   */
  bool MoveEefPos(const std::vector<double>& eef_pos) const;

  /**
   * @brief Asynchronously moves the robotic arm's end-effector to the specified position.
   * @param eef_pos A vector containing the target end-effector position.
   * @return A future representing the result of the move operation.
   *
   * Asynchronously moves the robotic arm's end-effector to the specified position. The target
   * position must be provided as a vector of doubles. The function returns a future that will
   * contain the result of the move operation.
   */
  std::future<bool> AsyncMoveEefPos(const std::vector<double>& eef_pos) const;

  /**
   * @brief Moves the robotic arm's end-effector to the specified position (single value).
   * @param eef_pos The target position value for the end-effector.
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm's end-effector to the specified position. The target position must be
   * provided as a single double value. The function returns true if the move operation is
   * successful, otherwise false.
   */
  bool MoveEefPos(const double& eef_pos) const;

  /**
   * @brief Asynchronously moves the robotic arm's end-effector to the specified position (single value).
   * @param eef_pos The target position value for the end-effector.
   * @return A future representing the result of the move operation.
   *
   * Asynchronously moves the robotic arm's end-effector to the specified position. The target position
   * must be provided as a single double value. The function returns a future that will contain the result
   * of the move operation.
   */
  std::future<bool> AsyncMoveEefPos(const double& eef_pos) const;

  /**
   * @brief Moves the robotic arm along specified Cartesian waypoints.
   * @param cart_waypoints A vector of waypoints represented as pairs of position (3D vector) and orientation (4D
   * quaternion).
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm along a series of Cartesian waypoints. Each waypoint is represented by a pair
   * of arrays: one for the position (x, y, z) and one for the orientation (quaternion: x, y, z, w).
   * The function returns true if the move operation is successful, otherwise false.
   */
  bool MoveWithCartWaypoints(
      const std::vector<std::pair<std::array<double, 3>, std::array<double, 4>>>& cart_waypoints) const;

  /**
   * @brief Asynchronously moves the robotic arm along specified Cartesian waypoints.
   * @param cart_waypoints A vector of waypoints represented as pairs of position (3D vector) and orientation (4D
   * quaternion).
   * @return A future representing the result of the move operation.
   *
   * Asynchronously moves the robotic arm along a series of Cartesian waypoints. Each waypoint is
   * represented by a pair of arrays: one for the position (x, y, z) and one for the orientation
   * (quaternion: x, y, z, w). The function returns a future that will contain the result of the
   * move operation.
   */
  std::future<bool> AsyncMoveWithCartWaypoints(
      const std::vector<std::pair<std::array<double, 3>, std::array<double, 4>>>& cart_waypoints) const;

  /**
   * @brief Moves the robotic arm along specified joint waypoints.
   * @param joint_waypoints A vector of joint positions to move through.
   * @return True if the move operation is successful, false otherwise.
   *
   * Moves the robotic arm along a series of joint waypoints. Each waypoint is represented by an array
   * of joint positions. The function returns true if the move operation is successful, otherwise false.
   */
  bool MoveWithJointWaypoints(const std::vector<std::array<double, 6>>& joint_waypoints) const;

  /**
   * @brief Asynchronously moves the robotic arm along specified joint waypoints.
   * @param joint_waypoints A vector of joint positions to move through.
   * @return A future representing the result of the move operation.
   *
   * Asynchronously moves the robotic arm along a series of joint waypoints. Each waypoint is
   * represented by an array of joint positions. The function returns a future that will contain the
   * result of the move operation.
   */
  std::future<bool> AsyncMoveWithJointWaypoints(const std::vector<std::array<double, 6>>& joint_waypoints) const;

  /**
   * @brief Sends integrated MIT control commands to the robotic arm's joints.
   * @param joint_pos An array of length 6 containing the target joint positions.
   * @param joint_vel An array of length 6 containing the target joint velocities.
   * @param joint_eff An array of length 6 containing the target joint efforts (torques).
   * @param joint_kp  An array of length 6 containing the target joint position gains (Kp).
   * @param joint_kd  An array of length 6 containing the target joint velocity gains (Kd).
   *
   * This function sends integrated MIT control commands to the robotic arm, allowing direct control
   * over each joint's position, velocity, effort, and control gains (Kp, Kd). All input arrays
   * must have a length of 6, corresponding to the 6 joints of the robotic arm. It is typically used
   * in advanced control modes where fine-grained, real-time control of the robot's actuators is required.
   *
   * @note Recommended call frequency: 250Hz.
   */
  void MitJointIntegratedControl(const std::array<double, 6>& joint_pos, const std::array<double, 6>& joint_vel,
                                 const std::array<double, 6>& joint_eff, const std::array<double, 6>& joint_kp,
                                 const std::array<double, 6>& joint_kd) const;

  /**
   * @brief Directly controls the robotic arm's joints to move to the specified positions.
   * @param joint_pos An array containing the target joint positions.
   *
   * Directly controls the robotic arm's joints to move to the specified positions. The target joint
   * positions must be provided as an array of doubles. This function is used in servo mode.
   */
  void ServoJointPos(const std::array<double, 6>& joint_pos) const;

  /**
   * @brief Directly controls the robotic arm's joints to move at the specified velocities.
   * @param joint_vel An array containing the target joint velocities.
   *
   * Directly controls the robotic arm's joints to move at the specified velocities. The target joint
   * velocities must be provided as an array of doubles. This function is used in servo mode.
   */
  void ServoJointVel(const std::array<double, 6>& joint_vel) const;

  /**
   * @brief Directly controls the robotic arm's end-effector position.
   * @param cart_pos A pair containing the target position (3D vector) and orientation (4D quaternion).
   *
   * Directly controls the robotic arm's end-effector position. The target position and orientation
   * must be provided as a pair of arrays. This function is used in servo mode.
   */
  void ServoCartPos(const std::pair<std::array<double, 3>, std::array<double, 4>>& cart_pos) const;

  /**
   * @brief Directly controls the robotic arm's twist (linear and angular velocity) in Cartesian space.
   * @param twist A pair containing the linear velocity (3D vector) and angular velocity (3D vector).
   *
   * Directly controls the robotic arm's twist (linear and angular velocity) in Cartesian space. The
   * target linear and angular velocities must be provided as a pair of arrays. This function is used
   * in servo mode.
   */
  void ServoCartTwist(const std::pair<std::array<double, 3>, std::array<double, 3>>& twist) const;

  /**
   * @brief Directly controls the robotic arm's end-effector position.
   * @param eef_pos A vector containing the target position of the end-effector.
   *
   * Directly controls the robotic arm's end-effector position. The target position must be provided
   * as a vector of doubles. This function is used in servo mode.
   */
  void ServoEefPos(const std::vector<double>& eef_pos) const;

  /**
   * @brief Directly controls the robotic arm's end-effector position (single value).
   * @param eef_pos The target position value for the end-effector.
   *
   * Directly controls the robotic arm's end-effector position. The target position must be provided
   * as a single double value. This function is used in servo mode.
   */
  void ServoEefPos(const double& eef_pos) const;

  /**
   * @brief Destructor that cleans up resources used by the SDK.
   *
   * Cleans up any resources used by the SDK, including disconnecting from the robotic arm if
   * necessary.
   */
  ~AirbotSdk();

 private:
  std::shared_ptr<spdlog::logger> logger_; /**< Logger instance for logging SDK events. */
  std::unique_ptr<AirbotArm>
      arm_; /**< Unique pointer to the AirbotArm instance used for controlling the robotic arm. */
};

}  // namespace airbot

#endif  // AIRBOT_SDK_HPP_
