#ifndef SPEED_PROFILE_HPP_
#define SPEED_PROFILE_HPP_

#include <cstdint>

/**
 * @file speed_profile.hpp
 * @brief Defines speed profiles for robot motion control.
 *
 * This file defines different speed settings that can be applied
 * to the robot's motion commands. Each profile provides a trade-off
 * between performance and safety.
 */

/// @namespace airbot
/// @brief Namespace containing all Airbot SDK related definitions.
namespace airbot {

/**
 * @enum SpeedProfile
 * @brief Enum representing predefined speed profiles for robot operation.
 *
 * This enum defines different speed modes that the robot can operate under,
 * balancing speed, precision, and safety according to application needs.
 */
enum class SpeedProfile : int {
  /**
   * @brief Default speed profile.
   *
   * Recommended for general-purpose tasks, providing a balanced
   * trade-off between speed and precision.
   */
  DEFAULT = 0,

  /**
   * @brief Slow speed profile.
   *
   * Optimized for safety and precision at the cost of reduced execution speed.
   * Recommended for delicate operations or during testing phases.
   */
  SLOW = 1,

  /**
   * @brief Fast speed profile.
   *
   * Enables high-speed operation.
   *
   * \warning This profile is experimental. High-speed movements may cause
   * damage to the robot or surrounding environment. Use with extreme caution.
   */
  FAST = 2,
};

}  // namespace airbot

#endif  // SPEED_PROFILE_HPP_
