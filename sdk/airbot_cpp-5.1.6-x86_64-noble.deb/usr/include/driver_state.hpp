#ifndef DRIVER_STATE_HPP_
#define DRIVER_STATE_HPP_

#include <cstdint>

/**
 * @file driver_state.hpp
 * @brief Defines operational states for the driver service.
 *
 * This file defines various operational states that the driver service
 * may enter during its lifecycle. Each state represents the current
 * condition or activity of the driver, covering initialization,
 * idle operation, application loading, error handling, and shutdown phases.
 */

/// @namespace airbot
/// @brief Namespace containing all Airbot SDK related definitions.
namespace airbot {

/**
 * @enum State
 * @brief Enum representing the operational states of the driver service.
 *
 * This enum describes the different lifecycle stages of the driver,
 * allowing external systems to monitor and respond to driver status changes.
 */
enum class State : int {
  /**
   * @brief Initialization state.
   *
   * The driver service is starting up and performing initial setup tasks.
   */
  INIT = 0,

  /**
   * @brief Shutdown state.
   *
   * The driver service is in the process of shutting down safely.
   */
  SHUTDOWN = 1,

  /**
   * @brief Power-on state.
   *
   * The driver service is powered on and conducting self-check routines.
   */
  POWERON = 2,

  /**
   * @brief Idle state.
   *
   * The driver service is running but not executing any commands.
   * It is waiting for instructions from the external SDK.
   */
  IDLE = 3,

  /**
   * @brief Application loading state.
   *
   * The driver service is currently loading the application required for operation.
   */
  APPLOADING = 4,

  /**
   * @brief Application loaded state.
   *
   * The application has been successfully loaded.
   *
   * If a read-write app is loaded, the robot may stay in a read-only state, allowing
   * the SDK to access robot states but not issue motion commands.
   */
  APPLOADED = 5,

  /**
   * @brief Error state.
   *
   * An error has occurred in the driver service, preventing normal operations.
   */
  ERROR = 6,
};

}  // namespace airbot

#endif  // DRIVER_STATE_HPP_
